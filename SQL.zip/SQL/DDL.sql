/*

													-----SQL Project------
															DML
												   Restaurent Management System
													-----Creator of Project----
														Md Shihab Uddin
													Trainee Id: 1266120
													Batch ID: ESAD-CS/PNTL-A/49/01
											-------------------------------------------

*/

USE master
GO

IF EXISTS(SELECT NAME FROM SYS.sysdatabases WHERE NAME='RestaurentManagementSystem')
DROP DATABASE RestaurentManagementSystem
GO

Create Database RestaurentManagementSystem
ON
(
	NAME='RestaurentManagementSystem_Data',
	FILENAME='E:\sql\RestaurentManagementSystem_Data.mdf',
	SIZE=50MB,
	MAXSIZE=100MB,
	FILEGROWTH=10%
)

LOG ON
(
	NAME='RestaurentManagementSystem_Log',
	FILENAME='E:\sql\RestaurentManagementSystem_Log.ldf',
	SIZE=10MB,
	MAXSIZE=20MB,
	FILEGROWTH=5%
)
GO
use RestaurentManagementSystem



Create table Branch (
Bra_Id int identity primary key,
[Location] Nvarchar(50) Not null,
)
Go

 Create table  Gender(
 Gen_Id int identity primary key,
 Gender NVARCHAR(20) CHECK(Gender  IN('Male','Female'))
 )
 Go

Create Table Customer(
Cus_Id int identity primary key,
[name] Nvarchar(50) not null,
Gen_Id int references Gender(Gen_Id),
contactNo VARCHAR(11) NOT NULL CHECK(contactNo LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
Email nvarchar(50) Default  'NA',
Membership NVARCHAR(20) CHECK(Membership IN('Regular','Silver','Gold','Platinum')),
Discount Float(10),
[Address] Nvarchar(100),
City Nvarchar(50)
)
Go

Create Table Employee(
Emp_Id int identity primary key,
[name] Nvarchar(50) Not null,
Gen_id int references Gender(Gen_Id),
contactNo VARCHAR(11) NOT NULL CHECK(contactNo LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
Email nvarchar(50) Default  'NA'
)
Go


Create table Depertment(
Dep_Id int identity primary key,
[Name] Nvarchar(20) Not null,
) 
Go


Create Table SalaryAndWage(
Sal_Id Int Identity Primary key,
Salary Money Not null,
Emp_Id int References Employee(Emp_Id),
Dep_Id Int references Depertment(Dep_Id)
)
Go

Create Table Supplier(
Sup_Id Int Identity primary Key,
[Name] Nvarchar(50) Not null,
Gen_id int references Gender(Gen_Id),
contactNo VARCHAR(11) Not null
)
Go

Create Table RowMaterial(
Row_Id int identity primary key,
Name Nvarchar(50) Not null,
Quantity Int Not null,
Price money  not null,
Total as  (Quantity*price)
)
Go

Create Table Item(
Item_id Int identity primary Key,
Item_Name Nvarchar(50) Not null
)
Go

Create table  [Order](
Ord_Id int identity primary key,
Ord_name Nvarchar(50) Not null,
Item_Id int references Item (Item_id),
Cus_Id int references Customer(Cus_Id),
[Date] Datetime Default Getdate() Not null
)
Go

Create Table OrderDtails(
OrdDteails_Id int identity Primary key,
Item_Id int references Item (Item_id),
UnitPrice Money Not null,
Quantity int Not null,
Discount Float Null,
NetPrice  as ((Quantity*Unitprice)-Quantity*Unitprice*Discount),
Vat float Not null
)
Go


Create Table Booking(
book_Id int identity Primary Key,
Cus_Id int references Customer(Cus_Id),
Bra_Id int references Branch(Bra_Id),
Booking_Date Datetime  Default Getdate() Not null,
Release_Date datetime Default Getdate()  Not null,
[Status] NVARCHAR(20) CHECK  ([Status] IN ('Empty','Booked'))
)
Go


--Alter Table Ddop Constraint 

Alter Table Employee
Drop Constraint  [CK__Employee__contac__300424B4]
Go


--Creat Index From Customer table
Select*from Item

CREATE INDEX IX_Customer
    ON Customer
    (Cus_id,[Name],Gen_id,ContactNo,Membership,Discount,Address,City)
	Go

--Creat NonIndex From Customer table

CREATE  NONCLUSTERED INDEX NIX_Item
    ON Item
    (Item_id,Item_name)
	Go

--Create View for department Wise salary

CREATE VIEW view_DeptWiseSalary
AS
Select  e.[name],d.[Name], sum(sw.Salary) as 'Total salary' from Employee e
join SalaryAndWage sw on sw.Emp_Id=e.Emp_Id
join Depertment D on D.Dep_Id=sw.Dep_Id
Group By e.[name],d.[Name] with cube
Go
	


--Create stored procedure for INSERTING data into Gender table

CREATE PROC sp_insertGender
			@Gender nvarchar(20)
AS
BEGIN
	INSERT INTO Gender VALUES(@Gender)
END
GO
--Create stored procedure for INSERTING data into Branch table
CREATE PROC sp_insertBranch
			@Location VARCHAR(50)
			
AS
BEGIN
	INSERT INTO [Branch] VALUES(@Location)
END
GO


--Create stored procedure for INSERTING data into Customer table


CREATE PROC sp_insertCustomer
							@name nvarchar(50),
							@gen_id int,
							@contactNo varchar(11),
							@Email nvarchar(50),
							@Membership NVARCHAR(20),
							@Discount Float(10),
							@Adress Nvarchar(100),
							@city Nvarchar (50)
							
AS

	INSERT INTO Customer (name,Gen_Id,contactNo,Email,Membership,Discount,Address,City)VALUES 
	(@name,@Gen_Id,@contactNo,@Email,@Membership,@Discount,@Adress,@city)

GO

--Create stored procedure for INSERTING data into Item table

CREATE PROC sp_insertItem
			@Item_name Nvarchar(50)
AS
BEGIN
	INSERT INTO Item VALUES(@Item_name)
END
GO

--Create stored procedure for data into Order table

CREATE PROC sp_insertOrder
			@Ord_name Nvarchar(50),
			@Item_Id int,
			@Cus_Id int,
			@Date Datetime
AS
BEGIN
	INSERT INTO [Order] VALUES(@Ord_name,@Item_Id,@Cus_Id,@Date)
END
GO

--Create stored procedure for data into OrderDtails table

CREATE PROC sp_insertOrderDtails			
			@Item_Id int,
			@unitPrice money,
			@Quantity int,
			@Discount float,
			@Vat Float
AS
BEGIN
	INSERT INTO OrderDtails VALUES(@Item_Id,@unitPrice,@Quantity,@Discount,@Vat)
END
GO


--Create stored procedure for data into booking table

CREATE PROC sp_insertBooking			
			@Cus_id int,
			@Bra_id int,
			@Booking_date Datetime,
			@Release_date Datetime,
			@Status Nvarchar(20)
AS
BEGIN
	INSERT INTO Booking VALUES(@Cus_id,@Bra_id,@Booking_date,@Release_date,@Status)
END
GO


---Create Function

CREATE Proc Sp_BranchInsertWithRturn
		    @Location VARCHAR(50)


AS

    Declare Bra_id int

	INSERT INTO Branch(Location) VALUES(@Location)


SELECT @Bra_id=IDENT_CURRENT('Branch')
RETURN @Ord_id
GO

--test
DECLARE @id INT
EXEC @id= Sp_branchIsertWithRturn 'Jessore'
PRINT 'New product inserted with Id : '+STR(@id)
GO


---Output pAramiter of Store pRocrdure

CREATE PROC spCustomerInsertWithOutParamioter
							
							@name nvarchar(50),
							@gen_id int,
							@contactNo varchar(11),
							@Email nvarchar(50),
							@Membership NVARCHAR(20),
							@Discount Float(10),
							@Adress Nvarchar(100),
							@city Nvarchar (50)
As

INSERT INTO Customer (name,Gen_Id,contactNo,Email,Membership,Discount,Address,City)VALUES 
	(@name,@Gen_Id,@contactNo,@Email,@Membership,@Discount,@Adress,@city)

	Select @Id=IDENT_CURRENT('Customer')
	Go

	Declare @cus_id int
	Exec spCustomerInsertWithOutParamioter 'Selim',1,'0164567890','sl2@ymail.com','Regular',.00,'Gazipur','Dhaka'  @cus_id Output
	Select @cus_id 'new Id'
	Go



--Appliing try Catch nad rais error On 
CREATE PROC spInsertbooking  
			@I int,
			@Ci int,
			@BrI int,
			@BD Datetime,
			@RD Datetime,
			@S Nvarchar(20)
AS
	BEGIN TRY
				INSERT INTO Booking VALUES(@i,@Ci,@BrI,@BD,@RD,@S)
				RETURN 0
	END TRY
	BEGIN CATCH
				DECLARE @m NVARCHAR(200)
				SET @m=ERROR_MESSAGE()
				RAISERROR(@m,10,1)
				RETURN ERROR_NUMBER()
	END CATCH
GO


--Scaler Function

CREATE FUNCTION FnCalorderdtails (@unitPrice MONEY,@quantity INT,@Discount FLOAT)
RETURNS MONEY
AS
BEGIN
		DECLARE @netPrce Money
		SET @discount=@unitPrice*@quantity*@discount
		RETURN @discount
END
GO




--Table Valued Function

CREATE FUNCTION fnorderdtailsOfItem (@ordDtails_id INT, @item_id INT)
RETURNS TABLE
AS
RETURN
(
	SELECT 
	SUM(unitPrice*quantity) 'Total Sales',
    SUM(unitPrice*quantity*discount) 'Total Discount',
	SUM(unitPrice*quantity*(1-discount)) 'Net Amount'
	FROM OrderDtails
	WHERE @ordDtails_id=@ordDtails_id AND @item_id=@item_id
)
Go

--Update for Insert Tigger

CREATE TRIGGER trOrderdtails
ON OrderDtails
FOR INSERT
AS
BEGIN
		DECLARE @i INT, 
				@q INT	 --for quantity
		SELECT @i=Item_Id,@q=quantity FROM inserted

		UPDATE [Order]
		SET Item_Id=Item_Id+@q
		WHERE Item_Id=@i
END


--update After Tigger

CREATE TRIGGER trOrderDtailsUpdate
ON Orderdtails
AFTER UPDATE
AS
BEGIN
		IF UPDATE(quantity)
		BEGIN
				DECLARE @i INT,
						@oq INT,
						@nq INT,
						@change INT
				SELECT @i=i.Item_Id,@oq=d.Quantity,@nq=i.quantity FROM inserted i
				INNER JOIN deleted d ON i.OrdDteails_Id =d.OrdDteails_Id
				SET @change=@nq-@oq

				UPDATE [Order]
				SET Item_Id=Item_Id-@change
				WHERE Ord_Id=@i

		END
END
GO

--Create TRIGGER for preventing data DELETE & Update from tbl_employeeLeave table
CREATE TRIGGER tr_lockGenderUpdateDelete
	ON Gender
	FOR UPDATE,DELETE
AS
	PRINT 'You can''t update or delete Gendere table!'
	ROLLBACK TRANSACTION
GO


--PREVENT DELETE FROM tblBranch
CREATE TRIGGER tr_priventDeleteranch
ON Branch
FOR DELETE
AS
BEGIN
 ROLLBACK TRANSACTION
 PRINT 'Sorry! You can''t delete branch Location!'
END
GO