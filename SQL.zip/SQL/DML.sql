/*

													-----SQL Project------
															DML
												   Restaurent Management System
													-----Creator of Project----
														Md Shihab Uddin
													Trainee Id: 1266120
													Batch ID: ESAD-CS/PNTL-A/49/01
											-------------------------------------------

*/

Use RestaurentManagementSystem
Go

--Insert Into Branch
Insert into Branch Values
('Dhaka'),('Chittagong'),('Khulna'),('Barishal'),('Rajshahi'),('Rangpur'),('Mymansing')
Go

--Insert Into Gender
Insert into Gender Values
('Male'),('Female')

----Insert Into Customer
Insert into customer values 
('Ripon',1,'01727979799','rp@Gmail.com','Silver',.05,'56/C,Dhanmondi','Dhaka'),
('Shipon',1,'01724277999','sp@Gmail.com','Regular',.00,'Doulatpur','Khulna'),
('Happy',2,'01927971119','hppy4@Gmail.com','Regular',.00,'Saidpur','Rangpur'),
('Raju',1,'01557979799','Rj@Gmail.com','Regular',.00,'Farmgate','Dhaka'),
('Mim',2,'01727979000','Mim@Gmail.com','Silver',.05,'56/C,Dhanmondi','Dhaka'),
('Shuvo',1,'01727997987','ss@Gmail.com','Platinum',.20,'Gulshan','Dhaka'),
('Rocky',1,'01928779799','Rk@Gmail.com','Silver',.05,'RN road','Magura'),
('Imam',1,'01728124999','imam@Gmail.com','Gold',.10,'College Road','Bhola'),
('Mamun',1,'01727380149','mamun@Gmail.com','Silver',.05,'Moinamoti','Comilla'),
('Nazmul',1,'01725500999','nazmul@Gmail.com','Regular',.00,'KK road,Feni','Feni'),
('Farida',2,'01823997999','farida33@Gmail.com','Regular',.00,'22/A Dhanmondi','Dhaka'),
('Maliha',2,'01669797444','mm57@Gmail.com','Silver',.05,'Khalishpur','Khulna'),
('Abbas',1,'01728126549','abs@Gmail.com','Regular',.00,'Sitakundu','Chittagong'),
('Nishat',2,'01628126103','ni57@Gmail.com','Regular',.00,'TB Road','Dinajpur'),
('Shimul',1,'01556126540','sm2@Gmail.com','Regular',.00,'Ashuganj','Barishal')
Go

--Insert Into Employee
insert into Employee values 
('Rita',2,'0170000099','rt@Gmail.com'),
('Robin',1,'0155555598','robin@Gmail.com'),
('Aleya',2,'0156666598','al44@gmail.com'),
('Shihab',1,'0155558495','sh57@Gmail.com'),
('Robi',1,'017444598','robin@Ymail.com'),
('Partho',1,'0185500598','Partho@ymail.com'),
('Jemi',2,'0185345598','jm87@Gmail.com')
Go

--Insert into depertment
Insert into Depertment values 
('Marketing'),
('HR'),
('Accounting'),
('Shape & Waitter')
Go


--Insert into Salary And wages
Insert into SalaryAndWage values
(10000,8,1),
(10000,2,4),
(20000,3,2),
(15000,4,3),
(8000,5,4),
(8000,6,4),
(10000,7,1)
Go

--Insert intp supplier
insert into Supplier values
('Rahim',1,'0171119099'),
('Karim',1,'0193426755'),
('Masum',1,'0182319099'),
('Bibek',1,'0181119091')
Go

--Insert into item
Insert into Item values
('Rice'),
('Chicken'),
('Refreshment')
Go

Insert into [Order] values
('Fried Rice',1,1,Getdate()),
('Tehari',1,2,Getdate()),
('Kacchi',1,3,Getdate()),
('Vuna Khichuri',1,4,Getdate()),
('BarB-Q',2,5,Getdate()),
('Chicken Fry',2,6,Getdate()),
('Pasty',2,7,Getdate()),
('Orio shek',3,8,Getdate()),
('Milk shek',3,9,Getdate()),
('Chocolate shek',3,10,Getdate()),
('Ice Cream chocolate',3,11,Getdate())
Go


--Insert Orderdetails
insert into  OrderDtails Values 
(1,150,150,.05,.15),
(1,100,150,.05,.15),
(1,160,200,.05,.15),
(1,120,200,.05,.15),
(2,120,200,.00,.15),
(2,120,150,.05,.15),
(2,150,150,.05,.15),
(3,150,100,.10,.15),
(3,150,100,.10,.15),
(3,180,80,.10,.15),
(3,70,150,.05,.15)
Go

--test insert

Select*from depertment
Select*from Employee 
Select*from SalaryAndWage
Select*from item
Select*from [order]
select*from OrderDtails
select*from Customer
select*from Item
Select*from Branch


--------Some Data entry Of store Procidure

Exec sp_insertGender 'Male'
Exec sp_insertGender'Female'
Go


Exec sp_insertBranch 'Dhaka'
Exec sp_insertBranch 'Chittagong'
Exec sp_insertBranch 'Khulna'
Exec sp_insertBranch 'Barishal'
Exec sp_insertBranch 'Rajshahi'
Exec sp_insertBranch 'Rangpur'
Exec sp_insertBranch 'Mymansing'
Go



Exec sp_insertItem 'Rice'
Exec sp_insertItem 'Chicken'
Exec sp_insertItem' Refreshment'
Go




 Exec sp_insertCustomer 'Ripon',1,'01727979799','rp@Gmail.com','Silver',.05,'56/C,Dhanmondi','Dhaka'
 Exec sp_insertCustomer 'Shipon',1,'01724277999','sp@Gmail.com','Regular',.00,'Doulatpur','Khulna'
 Exec sp_insertCustomer 'Happy',2,'01927971119','hppy4@Gmail.com','Regular',.00,'Saidpur','Rangpur'
 Exec sp_insertCustomer'Raju',1,'01557979799','Rj@Gmail.com','Regular',.00,'Farmgate','Dhaka'
 Exec sp_insertCustomer 'Mim',2,'01727979000','Mim@Gmail.com','Silver',.05,'56/C,Dhanmondi','Dhaka'
 Exec sp_insertCustomer'Shuvo',1,'01727997987','ss@Gmail.com','Platinum',.20,'Gulshan','Dhaka'
 Exec sp_insertCustomer 'Rocky',1,'01928779799','Rk@Gmail.com','Silver',.05,'RN road','Magura'
 Exec sp_insertCustomer 'Imam',1,'01728124999','imam@Gmail.com','Gold',.10,'College Road','Bhola'
 Exec sp_insertCustomer 'Mamun',1,'01727380149','mamun@Gmail.com','Silver',.05,'Moinamoti','Comilla'
 Exec sp_insertCustomer'Nazmul',1,'01725500999','nazmul@Gmail.com','Regular',.00,'KK road,Feni','Feni'
 Exec sp_insertCustomer 'Farida',2,'01823997999','farida33@Gmail.com','Regular',.00,'22/A Dhanmondi','Dhaka'
 Exec sp_insertCustomer'Maliha',2,'01669797444','mm57@Gmail.com','Silver',.05,'Khalishpur','Khulna'
 Exec sp_insertCustomer'Abbas',1,'01728126549','abs@Gmail.com','Regular',.00,'Sitakundu','Chittagong'
 Exec sp_insertCustomer'Nishat',2,'01628126103','ni57@Gmail.com','Regular',.00,'TB Road','Dinajpur'
 Exec sp_insertCustomer 'Shimul',1,'01556126540','sm2@Gmail.com','Regular',.00,'Ashuganj','Barishal'
  Go



Exec sp_insertOrder 'Fried Rice',1,1,Getdate
Exec sp_insertOrder 'Tehari',1,2,Getdate
Exec sp_insertOrder 'Kacchi',1,3,Getdate
Exec sp_insertOrder 'Vuna Khichuri',1,4,Getdate
Exec sp_insertOrder 'BarB-Q',2,5,Getdate
Exec sp_insertOrder 'Chicken Fry',2,6,Getdate
Exec sp_insertOrder 'Pasty',2,7,Getdate
Exec sp_insertOrder  'Orio shek',3,8,Getdate
Exec sp_insertOrder 'Milk shek',3,9,Getdate
Exec sp_insertOrder 'Chocolate shek',3,10,Getdate
Exec sp_insertOrder 'Ice Cream chocolate',3,11,Getdate
Go




 Exec sp_insertOrderDtails 1,150,150,.05,.15
Exec sp_insertOrderDtails 1,100,150,.05,.15
Exec sp_insertOrderDtails 1,160,200,.05,.15
Exec sp_insertOrderDtails 1,120,200,.05,.15
Exec sp_insertOrderDtails 2,120,200,.00,.15
Exec sp_insertOrderDtails 2,120,150,.05,.15
Exec sp_insertOrderDtails 2,150,150,.05,.15
Exec sp_insertOrderDtails 3,150,100,.10,.15
Exec sp_insertOrderDtails 3,150,100,.10,.15
Exec sp_insertOrderDtails 3,180,80,.10,.15
Exec sp_insertOrderDtails 3,70,150,.05,.15
Go



Exec sp_insertBooking 1,1,getdate,getdate,'Booked'
Exec sp_insertBooking 3,6,getdate,getdate,'Booked'
Exec sp_insertBooking 8,3,getdate,getdate,'Booked'
Exec sp_insertBooking 4,5,getdate,getdate,'Empty'
Exec sp_insertBooking 7,2,getdate,getdate,'Booked'


--Simple Query
Select*from Customer

Select cus_Id,[Name],City  from Customer Where Cus_id=6


--- Join Query

Select o.Ord_Id, i.item_name, Count (o.ord_name)  from Item i
inner join [Order] o on I.Item_id= o.Item_Id
inner join Customer c on c.Cus_Id=O.Ord_Id
Group by o.Ord_Id,i.item_name
having Count(o.ord_name)>=1
Go

--join Query Departmentwise salary by Using Rollup

Select  e.[name],d.[Name], sum(sw.Salary) as 'Total salary' from Employee e
join SalaryAndWage sw on sw.Emp_Id=e.Emp_Id
join Depertment D on D.Dep_Id=sw.Dep_Id
Group By e.[name],d.[Name] with Rollup 
Go


---Sub  Join Query

Select o.Ord_Id,count(O.Ord_name),c.City from Item i
inner join [Order] o on I.Item_id= o.Item_Id
inner join Customer c on c.Cus_Id=O.Ord_Id
where o.Ord_Id >any
(select  i.Item_Name, o.ord_name as 'Total'
group by o.Ord_Id)


---avilability Item name  by Case


select*from  Item

Select Item_Name,
Case
		When Item_Name='Rice' then 'Its availavle'
		When Item_Name='Chicken' then 'Its availavle'
		else'Not in list!'
	End 'Item Definition'
From Item
Go


--DateTime
SELECT CAST('2021-Dec-01 18:00pm' AS DATE) AS 'Date'
Go

SELECT CONVERT(TIME,'2021-Dec-01 18:00:13.553') AS 'Time'
Go

--test function
Select Dbo.FnCalorderdtails (120,100,.10)
go

--test
Select*from [dbo].[fnorderdtailsOfItem] (10,3)
Go


--test trigger
INSERT INTO orderDtails (item_id,quantity) VALUES(2,150)
Go


Select*from [Order]
select*From orderDtails
update OrderDtails set Quantity=100 where Id=3